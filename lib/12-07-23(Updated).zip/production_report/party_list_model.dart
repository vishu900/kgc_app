class GetPartyListModel {
  String NAME;
  var CODE;

  GetPartyListModel({
    required this.NAME,
    required this.CODE,
  });
}