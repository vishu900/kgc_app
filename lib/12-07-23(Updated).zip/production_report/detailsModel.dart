class DetailsModel{
  String machine_code, date, process, po_number, catalog_code, catalog_name, prod_day, prod_night, party_name, gate_entry, count_code,
  material_name, shade, brand, prod_qty, uom, godown, username, ins_date;
  DetailsModel({
    required this.machine_code,
    required this.date,
    required this.process,
    required this.po_number,
    required this.catalog_code,
    required this.catalog_name,
    required this.prod_day,
    required this.prod_night,
    required this.party_name,
    required this.gate_entry,
    required this.count_code,
    required this.material_name,
    required this.shade,
    required this.brand,
    required this.prod_qty,
    required this.uom,
    required this.godown,
    required this.username,
    required this.ins_date,
});
}