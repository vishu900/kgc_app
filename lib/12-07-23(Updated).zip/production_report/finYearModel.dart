class FinYearModel {
  String FINYEAR, FROM_DATE, TO_DATE;

  FinYearModel({
    required this.FINYEAR,
    required this.FROM_DATE,
    required this.TO_DATE
  });
}